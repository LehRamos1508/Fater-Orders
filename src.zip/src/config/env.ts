export const env = {
  apiBaseUrl: process.env.NEXT_PUBLIC_API_BASEURL as string,
};
