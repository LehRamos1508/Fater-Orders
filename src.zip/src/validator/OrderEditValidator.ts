import * as Yup from "yup";

export const ProductEditValidator = () => {
  return Yup.object().shape({
    date: Yup.date()
      .required("Campo obrigatório"),
    clientId: Yup.string()
      .required("Campo obrigatório")
      .length(11, "Campo deve ter 11 caracteres"),
    paymentMethod: Yup.number()
      .required("Campo obrigatório")
      .min(1, "Selecione um método de pagamento válido"),
    quantity: Yup.number()
      .min(0.01, "Campo deve ter ao menos 0.01")
      .required("Campo obrigatório"),
    total: Yup.number()
      .min(0.01, "Campo deve ter ao menos 0.01")
      .required("Campo obrigatório"),
  });
};
