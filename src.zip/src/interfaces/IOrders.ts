export interface IOrder {
  date: string;
  client_id: number;
  payment_method: number;
  quantity: number;
  total: number;
}
