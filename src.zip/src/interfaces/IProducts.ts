export interface IProduct {
  description: string;
  brand: string;
  value: number;
  weight: number;
  flavor: string;
}
